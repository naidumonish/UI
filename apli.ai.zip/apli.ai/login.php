<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>LOGIN | Apli.ai</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
		<style>
			body
			{
				background-color:#9400D3;
			}
			.form-control
			{
					border-radius:32px;
			}
		</style>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container-fluid decor_bg" id="content">
            <div class="row">
                <div class="container">
                    <div style="background-color:#FFFFFF; border-radius:32px; height:300px;" class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                        <form  action="loginsuccess.php" method="POST">
                        <center><h2>LOGIN</h2></center><br><br>
                            <div class="form-group">
                                <input type="email" class="form-control"  placeholder="Work Email Address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"  name="e-mail" required = "true"><?php //echo $_GET['m1']; ?>
                            </div>
							<div class="form-group">
                                <input type="password" class="form-control"  placeholder="Password" name="pass" required = "true"><?php //echo $_GET['m1']; ?>
                            </div>
							 <input type="checkbox" name="rempass" value="rempass"> Remember Password<br><br>
							<center><button style="background-color:#9400D3; color:#FFFFFF" class="form-control" type="submit" name="submit" class="btn btn-primary">LOGIN</button></center>
                        </form>
						
						
					</div>
                </div>
            </div>
        </div>
        <?php include "includes/footer.php"; ?>
    </body>
</html>