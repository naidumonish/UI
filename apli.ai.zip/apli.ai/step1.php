<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sign Up | Apli.ai</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
		<style>
input.invalid {
  background-color: #ffdddd;
}
.step1{
  height: 15px;
  width: 15px;
  margin:2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 1;
}
.step2{
  height: 15px;
  width: 15px;
  margin:2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}
.step3{
  height: 15px;
  width: 15px;
  margin:2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}
.step.finish {
  background-color: #4CAF50;
}
			body
			{
				background-color:#9400D3;
			}
			.form-control
			{
					border-radius:32px;
			}
		</style>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container-fluid decor_bg" id="content">
            <div class="row">
                <div class="container">
                    <div style="background-color:#FFFFFF; border-radius:32px; height:350px;" class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                        <form  action="step2.php" method="POST">
                        <center><h2>SIGN UP 1/3</h2></center><br><br>
                            <div class="form-group">
                                <input type="text" class="form-control"  placeholder="Full Name" name="name" required = "true">
                            </div>
							<center><button style="background-color:#9400D3; color:#FFFFFF" class="form-control" type="submit" name="submit" class="btn btn-primary">NEXT</button></center><br>
							<div style="text-align:center;margin-top:40px;">
								<span class="step1"></span>
								<span class="step2"></span>
								<span class="step3"></span>
							</div>
                        </form>																
					</div>
                </div>
            </div>
        </div>
        <?php include "includes/footer.php"; ?>
    </body>
</html>