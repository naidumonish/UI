<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Contact Us | Apli.ai</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
		<style>
			body
			{
				background-color:#9400D3;
			}
			.form-control
			{
					border-radius:32px;
			}
		</style>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container-fluid decor_bg" id="content">
            <div class="row">
                <div class="container">
                    <div style="background-color:#FFFFFF; border-radius:32px; height:375px;" class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                        <form  action="success.php" method="POST">
                        <center><h2>CONTACT US</h2></center>
                            <div class="form-group">
                                <input class="form-control" placeholder="Full Name" name="name"  required = "true" pattern="^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control"  placeholder="Company Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"  name="e-mail" required = "true"><?php //echo $_GET['m1']; ?>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control"  placeholder="Company Name" name="cname" required = "true"><?php //echo $_GET['m2']; ?>
                            </div>
                            <div class="form-group">
                                <input  type="text" class="form-control"  placeholder="Phone Number" name="contact" maxlength="10" size="10" required = "true">
                            </div>
                            <center><button style="background-color:#9400D3; color:#FFFFFF" class="form-control" type="submit" name="submit" class="btn btn-primary">SEND</button></center>
                        </form>
						<h6>Have Credentials?</h6>
						<center><a href="login.php"><button style="background-color:#9400D3; color:#FFFFFF" class="form-control" type="submit" name="submit" class="btn btn-primary">LOGIN</button></a></center>
					</div>
                </div>
            </div>
        </div>
        <?php include "includes/footer.php"; ?>
    </body>
</html>